#!/bin/bash
/usr/sbin/sshd -D